<?php
include("./index.html");
if($_POST){
$valor1 = $_POST['valor1'];
$valor2 = $_POST['valor2'];
$soma = $valor1+$valor2;
echo "<br><br>";
if($soma>20){
echo "Resultado da soma ".$valor1." + ".$valor2." = ".$soma."<font color='green'> maior que 20</font>";
echo "<br>Soma de ".$soma." + 8 = ".$soma+8;
}else{
echo "Resultado da soma ".$valor1." + ".$valor2." = ".$soma."<font color='#FF0000'> menor que 20</font>";
echo "<br>Resultado da subtração ".$soma." - 5 = ".$soma-5;
}
}
?>